package controller;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Instructor;
import util.HibernateUtil;

import org.hibernate.HibernateException;

import java.util.List;
import java.util.UUID;

public class InstructorDao {

    // Save Instructor
    public void saveInstructor(Instructor instructor) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(instructor);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Update Instructor
    public void updateInstructor(Instructor instructor) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(instructor);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete Instructor
    public void deleteInstructor(UUID id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Instructor instructor = session.get(Instructor.class, id);
            if (instructor != null) {
                session.delete(instructor);
                System.out.println("Instructor is deleted");
            }
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get Instructor by ID
    public Instructor getInstructorById(UUID id) {
        Instructor instructor = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            instructor = session.get(Instructor.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return instructor;
    }

    // Get all Instructors
    public List<Instructor> getAllInstructors() {
        List<Instructor> instructors = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            instructors = session.createQuery("FROM Instructor", Instructor.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return instructors;
    }
    
    public Instructor getInstructorByEmail(String email) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return (Instructor) session.createQuery("FROM Instructor WHERE email = :email")
                    .setParameter("email", email)
                    .uniqueResult();
        }
    }

}
