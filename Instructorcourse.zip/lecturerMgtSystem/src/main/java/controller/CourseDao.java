/*package controller;

import java.util.List;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Course;
import util.HibernateUtil;

public class CourseDao {
	 // Save Course
    public void saveCourse(Course course) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(course);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Update Course
    public void updateCourse(Course course) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(course);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Delete Course
    public void deleteCourse(UUID id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Course course = session.get(Course.class, id);
            if (course != null) {
                session.delete(course);
                System.out.println("Course is deleted");
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Get Course by ID
    public Course getCourseById(UUID id) {
        Course course = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            course = session.get(Course.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return course;
    }

    // Get all Courses
    public List<Course> getAllCourses() {
        List<Course> courses = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            courses = session.createQuery("FROM Course", Course.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return courses;
    }

}
*/
package controller;
import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Course;
import util.HibernateUtil;

import org.hibernate.HibernateException;

import java.util.List;
import java.util.UUID;

public class CourseDao {

    // Save Course
    public void saveCourse(Course course) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(course);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Update Course
    public void updateCourse(Course course) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(course);
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete Course
    public void deleteCourse(UUID id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Course course = session.get(Course.class, id);
            if (course != null) {
                session.delete(course);
                System.out.println("Course is deleted");
            }
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get Course by ID
    public Course getCourseById(UUID id) {
        Course course = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            course = session.get(Course.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return course;
    }

    // Get all Courses
    public List<Course> getAllCourses() {
        List<Course> courses = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            courses = session.createQuery("FROM Course", Course.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return courses;
    }
    public Course getCourseByName(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return (Course) session.createQuery("FROM Course WHERE title = :name")
                    .setParameter("name", name)
                    .uniqueResult();
        }
    }
    public List<Course> getCoursesByInstructorEmail(String email) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT c FROM Course c WHERE c.instructor.email = :email", Course.class)
                    .setParameter("email", email)
                    .list();
        }
    }


}
