/*package util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import model.Instructor;
import model.Course;

public class HibernateUtil {
    
    private static SessionFactory sessionFactory = null;

    public static SessionFactory getSession() {
        
        if (sessionFactory == null) {
            Configuration configuration = new Configuration();
            
            Properties settings = new Properties();
            
            settings.setProperty(Environment.URL, "jdbc:postgresql://localhost:5432/lecturer_management");
            settings.setProperty(Environment.USER, "postgres");
            settings.setProperty(Environment.PASS, "irafasha");
            settings.setProperty(Environment.SHOW_SQL, "true");
            settings.setProperty(Environment.HBM2DDL_AUTO, "create");
            //settings.setProperty(Environment.DRIVER, "org.postgresql.Driver");
            
            configuration.setProperties(settings);
            
            configuration.addAnnotatedClass(Instructor.class);
            configuration.addAnnotatedClass(Course.class);
            
            sessionFactory = configuration.buildSessionFactory();
        }
        
        return sessionFactory;
    }
}
*/
package util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import model.Course;
import model.Instructor;

import java.util.Properties;

public class HibernateUtil {
    private static final SessionFactory sessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();

            Properties settings = new Properties();
            settings.setProperty(Environment.URL, "jdbc:postgresql://localhost:5432/lecturer_management");
            settings.setProperty(Environment.USER, "postgres");
            settings.setProperty(Environment.PASS, "irafasha");
            settings.setProperty(Environment.SHOW_SQL, "true");
            settings.setProperty(Environment.HBM2DDL_AUTO, "update");

            configuration.setProperties(settings);

            // Add annotated classes
            configuration.addAnnotatedClass(Instructor.class);
            configuration.addAnnotatedClass(Course.class);

            // Initialize SessionFactory
            sessionFactory = configuration.buildSessionFactory();
        } catch (Exception e) {
            throw new ExceptionInInitializerError("Initial SessionFactory creation failed " + e);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
