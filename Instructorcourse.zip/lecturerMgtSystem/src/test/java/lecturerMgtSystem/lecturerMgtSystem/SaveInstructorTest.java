package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import java.util.UUID;

import org.hibernate.SessionFactory;
import org.junit.BeforeClass;
import org.junit.Test;

import controller.InstructorDao;
import model.Instructor;
import util.HibernateUtil;

public class SaveInstructorTest {
	private static InstructorDao instructorDao;
	private static SessionFactory sessionFactory;

    @BeforeClass
    public static void setup() {
        sessionFactory = HibernateUtil.getSessionFactory();
        instructorDao = new InstructorDao();
    }

    @Test
    public void testSaveInstructor() {
        // Create a new Instructor object
        Instructor instructor = new Instructor();
        //instructor.setId(UUID.randomUUID()); // Set random UUID
        instructor.setFirstName("pacifique");
        instructor.setLastName("irafasha");
        instructor.setEmail("irapac40@gmail.com");

        // Save Instructor
        try {
            instructorDao.saveInstructor(instructor);
        } catch (Exception e) {
            fail("Saving instructor failed: " + e.getMessage());
        }

        // Retrieve from DB to verify
        Instructor retrievedInstructor = instructorDao.getInstructorById(instructor.getId());
        assertNotNull("Instructor should not be null", retrievedInstructor);
        assertEquals("First name should match", "pacifique", retrievedInstructor.getFirstName());
        assertEquals("Last name should match", "irafasha", retrievedInstructor.getLastName());
        assertEquals("Email should match", "irapac40@gmail.com", retrievedInstructor.getEmail());
    }
		    

}
