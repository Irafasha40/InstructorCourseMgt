package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import controller.CourseDao;
import controller.InstructorDao;
import model.Course;
import model.Instructor;

public class CourseByEmailTest {

	private CourseDao courseDao = new CourseDao();
    private InstructorDao instructorDao = new InstructorDao();
	@Test
	public void test() {
		//fail("Not yet implemented");
		Instructor instructor = instructorDao.getInstructorByEmail("michael@example.com");
        assertNotNull(instructor);

        List<Course> courses = courseDao.getCoursesByInstructorEmail("michael@example.com");

        assertNotNull(courses);
        assertTrue(courses.size() > 0);
	}

}
