/*package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import org.hibernate.Session;
import org.junit.Test;

import util.HibernateUtil;

public class ConTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
     // Session session = HibernateUtil.getSession().openSession();
		
		//assertNotNull(session);
	}

}
*/