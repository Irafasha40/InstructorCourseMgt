package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import org.junit.Test;

import controller.CourseDao;
import model.Course;

public class DeleteCourseTest {

	private CourseDao courseDao = new CourseDao();
	@Test
	public void test() {
		//fail("Not yet implemented");
		Course course = courseDao.getCourseByName("Advanced Java");
        assertNotNull(course);

        courseDao.deleteCourse(course.getId());

        Course deleted = courseDao.getCourseByName("Advanced Java");
        assertNull(deleted);
	}

}
