package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import org.junit.Test;

import controller.InstructorDao;
import model.Instructor;

public class RetrieveInstructorTest {

	private InstructorDao instructorDao = new InstructorDao();
	@Test
	public void test() {
		//fail("Not yet implemented");
		Instructor instructor = instructorDao.getInstructorByEmail("chriss@gmail.com");
        assertNotNull(instructor);
	}

}
