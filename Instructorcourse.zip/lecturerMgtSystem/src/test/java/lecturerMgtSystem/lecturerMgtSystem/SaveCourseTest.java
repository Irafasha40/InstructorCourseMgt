package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import org.junit.Test;

import controller.CourseDao;
import controller.InstructorDao;
import model.Course;
import model.Instructor;

public class SaveCourseTest {
	private CourseDao courseDao = new CourseDao();
    private InstructorDao instructorDao = new InstructorDao();

	@Test
	public void test() {
		//fail("Not yet implemented");
		Instructor instructor = instructorDao.getInstructorByEmail("chriss@gmail.com");
        assertNotNull(instructor);

        Course course = new Course();
        course.setTitle("testing");
        course.setInstructor(instructor);
        courseDao.saveCourse(course);

        Course retrieved = courseDao.getCourseByName("testing");
        assertNotNull(retrieved);
        assertEquals("testing", retrieved.getTitle());
	}

}
