package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import org.junit.Test;

import controller.CourseDao;
import model.Course;

public class UpdateCourseTest {

	private CourseDao courseDao = new CourseDao();
	@Test
	public void test() {
		//fail("Not yet implemented");
		Course course = courseDao.getCourseByName("testing");
        assertNotNull(course);

        course.setTitle("best programming");
        courseDao.updateCourse(course);

        Course updated = courseDao.getCourseByName("best programming");
        assertEquals("best programming", updated.getTitle());
	}

}
