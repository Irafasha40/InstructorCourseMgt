package lecturerMgtSystem.lecturerMgtSystem;

import static org.junit.Assert.*;

import org.junit.Test;

import controller.InstructorDao;
import model.Instructor;

public class UpdateInstructorTest {
	private InstructorDao instructorDao = new InstructorDao();
	@Test
	public void test() {
		//fail("Not yet implemented");
		Instructor instructor = instructorDao.getInstructorByEmail("irapac40@gmail.com");
        assertNotNull(instructor);

        instructor.setFirstName("paccy");
        instructorDao.updateInstructor(instructor);

        Instructor updated = instructorDao.getInstructorByEmail("irapac40@gmail.com");
        assertEquals("paccy", updated.getFirstName());
	}

}
